<?php

namespace ShipperHQ\WS\Rate\Request;

use \ShipperHQ\WS\AbstractWebServiceRequest;
use \ShipperHQ\WS\WebServiceRequestInterface;

/**
 * Class RateRequest
 *
 * @package ShipperHQ\WS\Request\Rate
 */
class InfoRequest extends AbstractWebServiceRequest implements WebServiceRequestInterface
{
   /* function __construct()
    {

    }*/


}
