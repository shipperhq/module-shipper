<?php

namespace ShipperHQ\WS\Registration;

use \ShipperHQ\WS;

/**
 * Class UPSRegistrationResponse
 *
 * @package ShipperHQ\WS\Response\UPS\Registration
 */
class UPSRegistrationResponse extends AbstractWebServiceResponse implements WebServiceResponse
{

}
